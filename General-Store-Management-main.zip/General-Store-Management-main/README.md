# General-Store-Management

copy the main file and paste in your VS Code and thats it. The code works Fine.
